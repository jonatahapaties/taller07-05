 <?php
session_start();

 var_dump($_GET);

$_SESSION['usuario']= null;

//header("Location:listarSesion.php");
?>